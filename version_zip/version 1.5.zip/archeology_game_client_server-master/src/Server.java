import java.net.ServerSocket;

public class Server {

    public static void main(String[] args) throws Exception {
        ServerSocket listener = new ServerSocket(8901);
        System.out.println(" Chasse au tr�sor...Serveur connect�...");
        try {
            while (true) {
            	System.out.println(listener.getInetAddress());
                AppGame Game = new AppGame();
                Game.runplayer(listener);
                 
            }
        } finally {
            listener.close();
        }
    }
    
    
   
}


